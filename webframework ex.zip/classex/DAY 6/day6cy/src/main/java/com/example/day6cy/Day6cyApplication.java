package com.example.day6cy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day6cyApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day6cyApplication.class, args);
	}

}
