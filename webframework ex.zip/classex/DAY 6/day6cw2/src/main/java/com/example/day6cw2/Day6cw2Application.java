package com.example.day6cw2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day6cw2Application {

	public static void main(String[] args) {
		SpringApplication.run(Day6cw2Application.class, args);
	}

}
