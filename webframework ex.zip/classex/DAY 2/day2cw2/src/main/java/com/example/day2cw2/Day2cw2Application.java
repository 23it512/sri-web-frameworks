package com.example.day2cw2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day2cw2Application {

	public static void main(String[] args) {
		SpringApplication.run(Day2cw2Application.class, args);
	}

}
