package com.example.day1cw1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day1cw1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
